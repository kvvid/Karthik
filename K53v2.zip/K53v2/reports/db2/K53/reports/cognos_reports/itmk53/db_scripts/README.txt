Add additional tables to the database for IBM_TRAM:
-------------------------------------------------------------------------------------

The following instructions are for creating IBM_TRAM dimensions needed for creating Cognos data models:

We will create the following using the scripts: 
1. schema IBM_TRAM
2. Table TIME_DIMENSION: Time dimensional data for few years with granularity upto N mins (N can be specified by you). Each row of this table is a unique minute key with various dimensions related to it like hour, weekday, day of month, quarter etc 
3. Table MONTH_LOOKUP: Globalized Month names for Time Dimension
4. Table WEEKDAY_LOOKUP: Globalized weekday names for Time Dimension
5. Other dimensions conforming to Tivoli's Common Data Model i.e., ComputerSystem, BusinessService, SiteInfo etc

Instructions to create the dimensions
---------------------------------------

You will need admin access to create the IBM_TRAM.
 
Login as db2admin.
Connect to the database in which you want to create these dimension tables. It could be your TDW or any other database. (For e.g., db2 connect to WAREHOUS;)

1. Create schema and tables by running the following command: 

db2 -tf create_schema_IBM_TRAM.db2 

After this command executes successfully you will see several tables under IBM_TRAM : TIME_DIMENSION,  MONTH_LOOKUP ,  WEEKDAY_LOOKUP , ComputerSystem, BusinessService, SiteInfo etc

2. Populate TIME_DIMENSION table. 

Create storedProcedure for generating time dimension : 

	db2 -td@ -vf gen_time_dim_granularity_min.db2

Call the time dimension stored procedure with dates and granularity to generate the timestamps. 
For example the following command generates from 12/31/2007 to 12/31/2010 for 5 minutes granularity. You can generate 5 years at a stretch or have it regenerate the data everyday.

	call IBM_TRAM.CREATE_TIME_DIMENSION('2007-12-31-00.00.00.000000','2010-12-31-00.00.00.000000', 5); 



* To clean-up database from changes run db2 -tf clean.sql

* Be sure the reporting database user has permissions to the newly created tables and procedure
