#!/bin/sh +x
# ----------------------------------------------------------------
# Monitoring Agent for Services
# Version 623
# Script to configure historical collection for reporting
#
# COPYRIGHTS TIVOLI COE
#
# This file was created by the IBM Tivoli Monitoring Agent Builder
# Version 6.2.3.1
#	IBM Tivoli Monitoring Agent Generator 6.2.3.1 201203140621
#	IBM Tivoli Monitoring Agent Builder CIM Data Provider 6.2.3.1 201203140621
#	IBM Tivoli Monitoring Agent Builder Custom Data Provider 6.2.3.1 201203140621
#	IBM Tivoli Monitoring Agent Builder HTTP Data Provider 6.2.3.1 201203140621
#	IBM Tivoli Monitoring Agent Builder ICMP Data Provider 6.2.3.1 201203140621
#	IBM Tivoli Monitoring JDBC Data Provider 6.2.3.1 201203140621
#	IBM Tivoli Monitoring JMX Data Provider 6.2.3.1 201203140621
#	IBM Tivoli Monitoring Agent Builder Log Data Provider 6.2.3.1 201203140621
#	IBM Tivoli Monitoring Agent Builder SNMP Data Provider 6.2.3.1 201203140621
#	IBM Tivoli Monitoring Agent Builder WMI Data Provider 6.2.3.1 201203140621
#	IBM Tivoli Monitoring TMS DLA Plugin 6.2.3.1 201203140621
#	IBM Tivoli Monitoring Agent Builder UI 6.2.3.1 201203140621
#	IBM Tivoli Monitoring Remote Deploy 6.2.3.1 201203140621
#	IBM Tivoli Monitoring Agent Builder Common 6.2.3.1 201203140621
#	IBM Tivoli Omnibus 6.2.3 201203140621
# ----------------------------------------------------------------
# This script will configure historical collection for the following attribute groups
#	K53_PERFORMANCE_OBJECT_STATUS
# ----------------------------------------------------------------
usage()
{
    echo "Usage:"
    echo "	configuretdw.sh"
    echo "		-h <Candle Home>"
    echo "		-s <TEPS host>"
    echo "		-u <TEPS user>"
    echo "		[-p <TEPS password>]"
    echo "		-n <TEMS> | -m <Managed System Groups>"
    echo "		[-c <Collection Interval>]"
    echo "		[-r Pruning Interval]"
    exit 1
}

# Parse the switches
# The following switchs are supported
# -h
# -s
# -u
# -p
# -n
# -m
# -c
# -r
unset CANDLE_HOME
unset TEPS_HOST
unset TEPS_USER
unset TEPS_PASSWORD
unset TEMS_LIST
unset MS_LIST
unset C_INTERVAL
unset P_INTERVAL
unset ARGS
while getopts "h:s:u:p:n:m:c:r:" opt;
do
case $opt in
h)
    # Candle Home
    CANDLE_HOME=$OPTARG
    ;;
s)
    # TEPS Host
    TEPS_HOST=$OPTARG
    ;;
u)
    # TEPS User
    TEPS_USER=$OPTARG
    ;;
p)
    # TEPS Password
    TEPS_PASSWORD=$OPTARG
    ;;
n)
    # TEMS List
    TEMS_LIST=$OPTARG
    ;;
m)
    # Managed System List
    MS_LIST=$OPTARG
    ;;
c)
    # Collection Interval
    C_INTERVAL=$OPTARG
    ;;
r)
    # Pruning Interval
    P_INTERVAL=$OPTARG
    ;;
*)
    # Invalid option
    usage
    ;;
esac
done

if [ -z "$CANDLE_HOME"  ]; then
    echo "Candle home not specified"
    usage
fi
if [ -z "$TEPS_HOST"  ]; then
    echo "TEPS host not specified"
    echo "Using local host"
    TEPS_HOST="localhost"
fi
if [ -z "$C_INTERVAL"  ]; then
    echo "Collection interval not defined"
    echo "Using 1 hour"
    C_INTERVAL="1h"
fi
if [ -z "$P_INTERVAL"  ]; then
    echo "Pruning interval not defined"
    echo "Using 2 days"
    P_INTERVAL="2d"
fi
if [ -z "$TEPS_USER"  ]; then
    echo "TEPS username not specified"
    usage
fi
if [ -z "$TEMS_LIST"  ]; then
    if [ -z "$MS_LIST"  ]; then
        echo "No TEMS or Managed System list specified"
        usage
    else
        ARGS="-m $MS_LIST"
    fi
else
    if [ -z "$MS_LIST"  ]; then
        ARGS="-n $TEMS_LIST"
    else
        echo "Cannot specify -n and -m together"
        usage
    fi
fi

# Perform the logon
if [ -z "$TEPS_PASSWORD"  ]; then
    # No password specified
    # Allow the cli to prompt
    $CANDLE_HOME/bin/tacmd tepslogin -s $TEPS_HOST -u $TEPS_USER
else
    $CANDLE_HOME/bin/tacmd tepslogin -s $TEPS_HOST -u $TEPS_USER -p $TEPS_PASSWORD
fi

if [ $? -ne 0  ]; then
    echo "Error logging on"
    exit 1
fi

# Create the historical collections
$CANDLE_HOME/bin/tacmd histcreatecollection -t 53 -o "K53_PERFORMANCE_OBJECT_STATUS" -c $C_INTERVAL -i $C_INTERVAL -a "K53_PERFORMANCE_OBJECT_STATUS"

# Start the historical collection
$CANDLE_HOME/bin/tacmd histstartcollection -a "K53_PERFORMANCE_OBJECT_STATUS" $ARGS

# Configure pruning for the collections.
# We don't want the tables to keep growing.
# Only keep raw data for 2 days.
$CANDLE_HOME/bin/tacmd histconfiguregroups -m -t 53 -o "K53_PERFORMANCE_OBJECT_STATUS" -p R=$P_INTERVAL
