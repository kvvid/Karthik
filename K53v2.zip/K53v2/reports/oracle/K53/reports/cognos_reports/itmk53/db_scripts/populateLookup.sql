----------------------------------------
--Build Date 11/03/28 17:21:39
----------------------------------------

INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES 
(1, 'January', 'January_FR', '', '', '', '', '', '', '', '', '', '','','' );

INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES 
(2, 'February', 'February_FR', '', '', '', '', '', '', '', '', '', '','','');
INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES 
(3, 'March', 'March_FR', '', '', '', '', '', '', '', '', '', '','','') ;
INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES
(4, 'April', 'April_FR', '', '', '', '', '', '', '', '', '', '','','');
INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES
(5, 'May', 'May_FR', '', '', '', '', '', '', '', '', '', '','','') ;
INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES
(6, 'June', 'June_FR', '', '', '', '', '', '', '', '', '', '','','') ;
INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES
(7, 'July', 'July_FR', '', '', '', '', '', '', '', '', '', '','','');
INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES
(8, 'August', 'August_FR', '', '', '', '', '', '', '', '', '', '','','');
INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES
(9, 'September', 'September_FR', '', '', '', '', '', '', '', '', '', '','','');
INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES
(10, 'October', 'October_FR', '', '', '', '', '', '', '', '', '', '','','') ;
INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES
(11, 'November', 'November_FR', '', '', '', '', '', '', '', '', '', '','','') ;
INSERT into IBM_TRAM.MONTH_LOOKUP
( MONTH_NUMBER,    MONTH_EN,    MONTH_FR,    MONTH_PT_BR,    MONTH_JA,    MONTH_DE,    MONTH_IT,    MONTH_KO,    MONTH_CS,    MONTH_HU,    MONTH_PL,    MONTH_RU,    MONTH_ZH_CN,    MONTH_ZH_TW,    MONTH_ES )
VALUES
(12, 'December', 'December_FR', '', '', '', '', '', '', '', '', '', '','','');

INSERT into IBM_TRAM.WEEKDAY_LOOKUP
(WEEKDAY_NUMBER,WEEKDAY_EN,WEEKDAY_FR,WEEKDAY_PT_BR,WEEKDAY_JA,WEEKDAY_DE,WEEKDAY_IT,WEEKDAY_KO,WEEKDAY_CS,WEEKDAY_HU,WEEKDAY_PL,WEEKDAY_RU,WEEKDAY_ZH_CN,WEEKDAY_ZH_TW,WEEKDAY_ES)
VALUES 
(1, 'Sunday', 'Sunday_FR', '', '', '', '', '', '', '', '', '', '','','' ); 

INSERT into IBM_TRAM.WEEKDAY_LOOKUP
(WEEKDAY_NUMBER,WEEKDAY_EN,WEEKDAY_FR,WEEKDAY_PT_BR,WEEKDAY_JA,WEEKDAY_DE,WEEKDAY_IT,WEEKDAY_KO,WEEKDAY_CS,WEEKDAY_HU,WEEKDAY_PL,WEEKDAY_RU,WEEKDAY_ZH_CN,WEEKDAY_ZH_TW,WEEKDAY_ES)
VALUES 
(2, 'Monday', 'Monday_FR', '', '', '', '', '', '', '', '', '', '','',''); 

INSERT into IBM_TRAM.WEEKDAY_LOOKUP
(WEEKDAY_NUMBER,WEEKDAY_EN,WEEKDAY_FR,WEEKDAY_PT_BR,WEEKDAY_JA,WEEKDAY_DE,WEEKDAY_IT,WEEKDAY_KO,WEEKDAY_CS,WEEKDAY_HU,WEEKDAY_PL,WEEKDAY_RU,WEEKDAY_ZH_CN,WEEKDAY_ZH_TW,WEEKDAY_ES)
VALUES 
(3, 'Tuesday', 'Tuesday_FR', '', '', '', '', '', '', '', '', '', '','',''); 

INSERT into IBM_TRAM.WEEKDAY_LOOKUP
(WEEKDAY_NUMBER,WEEKDAY_EN,WEEKDAY_FR,WEEKDAY_PT_BR,WEEKDAY_JA,WEEKDAY_DE,WEEKDAY_IT,WEEKDAY_KO,WEEKDAY_CS,WEEKDAY_HU,WEEKDAY_PL,WEEKDAY_RU,WEEKDAY_ZH_CN,WEEKDAY_ZH_TW,WEEKDAY_ES)
VALUES 
(4, 'Wednesday', 'Wednesday_FR', '', '', '', '', '', '', '', '', '', '','','');

INSERT into IBM_TRAM.WEEKDAY_LOOKUP
(WEEKDAY_NUMBER,WEEKDAY_EN,WEEKDAY_FR,WEEKDAY_PT_BR,WEEKDAY_JA,WEEKDAY_DE,WEEKDAY_IT,WEEKDAY_KO,WEEKDAY_CS,WEEKDAY_HU,WEEKDAY_PL,WEEKDAY_RU,WEEKDAY_ZH_CN,WEEKDAY_ZH_TW,WEEKDAY_ES)
VALUES 
(5, 'Thursday', 'Thursday_FR', '', '', '', '', '', '', '', '', '', '','','');

INSERT into IBM_TRAM.WEEKDAY_LOOKUP
(WEEKDAY_NUMBER,WEEKDAY_EN,WEEKDAY_FR,WEEKDAY_PT_BR,WEEKDAY_JA,WEEKDAY_DE,WEEKDAY_IT,WEEKDAY_KO,WEEKDAY_CS,WEEKDAY_HU,WEEKDAY_PL,WEEKDAY_RU,WEEKDAY_ZH_CN,WEEKDAY_ZH_TW,WEEKDAY_ES)
VALUES 
(6, 'Friday', 'Friday_FR', '', '', '', '', '', '', '', '', '', '','',''); 

INSERT into IBM_TRAM.WEEKDAY_LOOKUP
(WEEKDAY_NUMBER,WEEKDAY_EN,WEEKDAY_FR,WEEKDAY_PT_BR,WEEKDAY_JA,WEEKDAY_DE,WEEKDAY_IT,WEEKDAY_KO,WEEKDAY_CS,WEEKDAY_HU,WEEKDAY_PL,WEEKDAY_RU,WEEKDAY_ZH_CN,WEEKDAY_ZH_TW,WEEKDAY_ES)
VALUES 
(7, 'Saturday', 'Saturday_FR', '', '', '', '', '', '', '', '', '', '','','');

commit;
