----------------------------------------
--Build Date 11/03/28 17:21:39
----------------------------------------

CREATE OR REPLACE 
PROCEDURE create_time_dimension(
 pv_startDate VARCHAR2,
 pv_endDate VARCHAR2,
 pv_granularity VARCHAR2

) is
loaddate TIMESTAMP  := TO_TIMESTAMP(to_date(pv_startDate, 'yyyy-mm-dd HH24:MI') ) ;
endDate  TIMESTAMP  := TO_TIMESTAMP(to_date(pv_endDate, 'yyyy-mm-dd HH24:MI') ) ;
granularity number := to_number(pv_granularity); -- force validation of the number
endloaddate TIMESTAMP;
v_year    number;
v_month   number;
v_day     number;
v_hour    number;
v_minute  number;
v_qurter  number;
v_week  number;
v_check number;
v_day_of_week  number;
v_day_of_year  number;
v_days_in_month  number;
v_day_name    VARCHAR2(30);
v_month_name  VARCHAR2(30);
v_week_key TIMESTAMP;
v_year_end number;
v_month_end number;
v_day_end number;
v_hour_end number;
v_minute_end number;
begin
 if loaddate is null or endDate is null or granularity is null  then
      dbms_output.put_line('! Empty parameter(s) ');
      dbms_output.put_line('Usage: CREATE_TIME_DIMENSION( startDate, endDate, granularity) ');
      return;
 end if;
 dbms_output.put_line('Creating time dimension');
 dbms_output.put_line('Start date = ' || pv_startDate || ' ,  end date = '|| pv_endDate || ' , granularity = ' || pv_granularity );

 /* loop date till end period reached */
 loop
   begin

    select loaddate +  granularity/(60*24) into loaddate  from dual;
    select loaddate + (granularity-1)/(60*24) into endloaddate  from dual;

    /* check if redord already exists */
    select count(*)
      into v_check
      from TIME_DIMENSION
     where TIME_RANGE_START = to_date(to_char(loaddate, 'yyyy-mm-dd HH24:MI'),'yyyy-mm-dd HH24:MI' );--trunc(loaddate, 'mi');

    if v_check = 0 then
      select
          to_char(loaddate,'yyyy'), to_char(loaddate,'mm'), to_char(loaddate,'dd'),
          to_char(loaddate,'HH24'), to_char(loaddate,'mi'), to_char(loaddate,'Q'), to_char(loaddate,'ww'),
          to_char(loaddate,'D'), to_char(loaddate,'DDD'),
          trim(to_char(loaddate,'DAY')), trim(to_char(loaddate,'MONTH')),
          ADD_MONTHS(to_date(TO_CHAR( loaddate, 'yyyy-mm')||'-01', 'yyyy-mm-dd'),1)
          - to_date(TO_CHAR( loaddate, 'yyyy-mm')||'-01', 'yyyy-mm-dd'),
          to_char(endloaddate,'yyyy'), to_char(endloaddate,'mm'), to_char(endloaddate,'dd'),
          to_char(endloaddate,'HH24'), to_char(endloaddate,'mi'),
          loaddate -(to_char(loaddate,'D')-1)
      into
          v_year, v_month   , v_day ,
          v_hour, v_minute, v_qurter  , v_week ,
          v_day_of_week , v_day_of_year ,
          v_day_name    , v_month_name  ,
          v_days_in_month,
          v_year_end, v_month_end, v_day_end, v_hour_end, v_minute_end,
          v_week_key
      from dual;

      insert into TIME_DIMENSION (
        CANDLETIMESTAMP,
        END_CANDLETIMESTAMP,
        TIME_RANGE_START,
        TIME_RANGE_END,
        HOUR_KEY,
        DAY_KEY,
        WEEK_KEY,
        MONTH_KEY,
        QUARTER_KEY,
        YEAR_KEY,
        CURRENT_DATE,
        CURRENT_MINUTE,
        CURRENT_HOUR,
        CURRENT_DAY,
        CURRENT_WEEK,
        CURRENT_MONTH,
        CURRENT_QUARTER,
        CURRENT_YEAR,
        DAY_OF_WEEK,
        DAYS_IN_MONTH,
        DAY_OF_YEAR,
        WEEK_OF_MONTH,
        WEEK_OF_QUARTER
      ) values (
        (to_char((v_year - 1900)*1000000 + v_month *10000 + v_day *100 + v_hour )) || lpad(v_minute,2,'0') || '00000',
        (to_char((v_year_end - 1900)*1000000 + v_month_end *10000 + v_day_end *100 + v_hour_end )) || lpad(v_minute_end,2,'0') || '59999',
        to_date(to_char(loaddate, 'yyyy-mm-dd HH24:MI'),'yyyy-mm-dd HH24:MI' ), --trunc(loaddate, 'mi'),
        to_date(to_char(endloaddate, 'yyyy-mm-dd HH24:MI'),'yyyy-mm-dd HH24:MI' ), --trunc(endloaddate, 'mi'),
        to_date(to_char(loaddate, 'yyyy-mm-dd HH24'),'yyyy-mm-dd HH24' ), --trunc(loaddate, 'HH24'),
        to_date(to_char(loaddate, 'yyyy-mm-dd'),'yyyy-mm-dd' ), --trunc(loaddate ,'DD'),
        to_date(to_char(loaddate, 'yyyy-mm-dd'),'yyyy-mm-dd') - to_number(to_char(loaddate, 'D') )+1,--trunc(loaddate ,'DAY'), -- returns 1th day of the week
        to_date(to_char(loaddate, 'yyyy-mm'),'yyyy-mm' ), --trunc(loaddate ,'MONTH'),
        to_date(to_char(loaddate, 'yyyy') ||'-'||decode(to_char(loaddate, 'Q'),'1','01-01','2','04-01','3','07-01','10-01'),'yyyy-mm-dd' ), --trunc(loaddate ,'Q'),
        to_date(to_char(loaddate, 'yyyy') ||'-01-01','yyyy-mm-dd' ), --trunc(loaddate ,'Y'),
        to_date(to_char(loaddate, 'yyyy-mm-dd'),'yyyy-mm-dd' ), --trunc(loaddate ,'DD'),
        v_minute,
        v_hour,
        v_day,
        v_week,
        v_month,
        v_qurter,
        v_year,
        v_day_of_week,
        v_days_in_month,
        v_day_of_year,
        v_day/7 + 1,
        v_week - (v_qurter -1)*13
     );
   end if;
   end;
  EXIT WHEN  loaddate  >= endDate;
 end loop;

 commit;
end;
/