/**************************************************************
  IBM Tivoli Monitoring Agent Builder

  (C) Copyright IBM Corporation 2011. All rights reserved.

  Script that creates the ManagedSystem table and indexes. The 
  ManagedSystem table is used for the ManagedSystem dimension in
  Cognos reports.

  Change "ITMUSER" to your Tivoli Data Warehouse user id.

  Parameters:
  - tablespace in which to create the table

  To run the script using SQL*Plus:
  sqlplus <user>/<password>@<oracle SID> @./create_table.sql
 **************************************************************/
WHENEVER SQLERROR CONTINUE;

define def_tbsp =&1

CREATE TABLE "ITMUSER".ManagedSystem (
  ManagedSystemName VARCHAR2 (64) NOT NULL,
  FullyQualifiedHostname VARCHAR2 (384),
  DisplayName VARCHAR2 (64) NOT NULL,
  AgentType  VARCHAR2 (32)  NOT NULL,
  ParentMSN VARCHAR2(64)
) TABLESPACE &def_tbsp;

CREATE UNIQUE INDEX "ITMUSER".IXManagedSystem ON ManagedSystem
(ManagedSystemName)    
 PCTFREE 20; 

CREATE INDEX "ITMUSER".IXParentMSN ON ManagedSystem
(ParentMSN)    
PCTFREE 20; 
