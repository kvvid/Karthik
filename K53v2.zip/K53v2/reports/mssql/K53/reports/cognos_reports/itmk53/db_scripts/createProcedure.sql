----------------------------------------
--Build Date 11/03/28 17:21:38
----------------------------------------

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON
USE IBM_TRAM
GO

-- clean old version
IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_NAME = N'CREATE_TIME_DIMENSION' AND ROUTINE_TYPE = N'PROCEDURE' AND ROUTINE_SCHEMA = N'IBM_TRAM')
	DROP PROCEDURE IBM_TRAM.CREATE_TIME_DIMENSION;
GO

-- create new verion  
CREATE PROCEDURE IBM_TRAM.CREATE_TIME_DIMENSION
@startDate VARCHAR(32), 
@endDate VARCHAR(32), 
@granularity smallint,
@weekday smallint = 7
as
begin 
  set NOCOUNT ON;
  /* iteration and boundary */  
  declare @loaddate datetime;
  declare @endloaddate datetime;
  declare @v_endDate datetime;    
  declare @v_counter int;
  declare @v_added int;
  /* placeholder for convertion */
  declare @v_start_candle CHAR(16);
  declare @v_end_candle CHAR(16);
  declare @v_start_minute_key datetime;
  declare @v_end_minute_key   datetime;
  declare @v_hour_key datetime;
  declare @v_day_key  datetime;
  declare @v_week_key  datetime;
  declare @v_month_key   datetime;
  declare @v_quarter_key  datetime;
  declare @v_year_key    datetime;
  declare @v_crrnt_mnt smallint;
  declare @v_crrnt_hr   smallint;
  declare @v_crrnt_d    smallint;
  declare @v_crrnt_wk   smallint;
  declare @v_crrnt_mnth smallint;
  declare @v_crrnt_qrtr smallint;
  declare @v_crrnt_yr   smallint;
  declare @v_day_of_week smallint;
  declare @v_day_of_mnth smallint;
  declare @v_day_of_yr   smallint;
  declare @v_week_of_mnth smallint;
  declare @v_week_of_qrtr smallint;
    
  
  set @loaddate  = convert(datetime, @startDate,  120);
  set @endloaddate = dateadd(minute, @granularity-1 , @loaddate) ; 
  set @v_endDate = convert(datetime, @endDate,  120);

  /* !!! set Sunday as 1 day of the week */
  if (@weekday > 7 or @weekday <1 )
    set DateFirst 7;
  else 
    set DateFirst @weekday;
    
  set @v_counter = 0;
  set @v_added = 0;
  while @loaddate <= @v_endDate
  begin

    set @v_start_minute_key = dateadd(mi, datediff(mi, 0, @loaddate), 0);
    set @v_end_minute_key   = dateadd(ss,59,dateadd(ms,998, dateadd(mi, datediff(mi, 0, @endloaddate), 0)));    
    set @v_counter = @v_counter + 1;
    if not exists (select 1 from IBM_TRAM.TIME_DIMENSION where TIME_RANGE_START = @v_start_minute_key) 
    begin
      set @v_added = @v_added +1 ;    
      set @v_start_candle = convert(varchar,(year(@loaddate)-1900)*1000000 +month(@loaddate)*10000+day(@loaddate)*100 + datepart(hour, @loaddate))
                         + replicate('0',2- len(convert(varchar,datepart( minute, @loaddate))))
                         + convert(varchar,datepart( minute, @loaddate))
                         + N'00000';

      set @v_end_candle = convert(varchar,(year(@endloaddate)-1900)*1000000 +month(@endloaddate)*10000+day(@endloaddate)*100 + datepart(hour, @endloaddate))
                         + replicate('0',2- len(convert(varchar,datepart( minute, @endloaddate))))
                         + convert(varchar,datepart( minute, @endloaddate))
                         + N'59999';
                           
      set @v_hour_key = dateadd(hour, datediff(hour, 0, @loaddate), 0);
      set @v_day_key = dateadd(day, datediff(day, 0, @loaddate), 0);
      set @v_week_key = dateadd(dd, -datepart(WeekDay, @loaddate),@loaddate);
      set @v_month_key = dateadd(month, datediff(month, 0, @loaddate), 0);
      set @v_quarter_key = dateadd(quarter, datediff(quarter, 0, @loaddate), 0);
      set @v_year_key = dateadd(year, datediff(year, 0, @loaddate), 0);
      set @v_crrnt_mnt = datepart( minute, @loaddate);    
      set @v_crrnt_hr = datepart( hour, @loaddate);
      set @v_crrnt_d    = day(@loaddate);
      set @v_crrnt_mnth = month(@loaddate);    
      set @v_crrnt_wk   = datediff(ww,dateadd(yy, datediff(yy,  0, @loaddate),0),dateadd(ww, datediff(ww,  0, @loaddate),0));
      set @v_crrnt_qrtr = datediff(qq, dateadd(yy, datediff(yy,  0, @loaddate),0), dateadd(qq, datediff(qq,  0, @loaddate),0))+1 ;
      set @v_crrnt_yr   = year(@loaddate);
      set @v_day_of_week = datepart(WeekDay, @loaddate);
      set @v_day_of_mnth = datediff(dd, dateadd(mm, datediff(mm,  0, @loaddate),0), dateadd(mm, 1, dateadd(mm, datediff(mm, 0, @loaddate),0)));
      set @v_day_of_yr   = datediff(dd, dateadd(yy, datediff(yy,  0, @loaddate),0),@loaddate) + 1 ;    
      set @v_week_of_mnth = datepart(dd, @loaddate)/7+1; 
      set @v_week_of_qrtr = @v_crrnt_wk - (@v_crrnt_qrtr -1)*13;
   	         	    
      insert into IBM_TRAM.TIME_DIMENSION (
        CANDLETIMESTAMP, END_CANDLETIMESTAMP, TIME_RANGE_START, TIME_RANGE_END, HOUR_KEY, DAY_KEY, WEEK_KEY,
        MONTH_KEY, QUARTER_KEY, YEAR_KEY, [CURRENT_DATE],	    
        CURRENT_MINUTE, CURRENT_HOUR, CURRENT_DAY, CURRENT_WEEK, CURRENT_MONTH, CURRENT_QUARTER, CURRENT_YEAR,	    
        DAY_OF_WEEK,DAYS_IN_MONTH,DAY_OF_YEAR,    
        WEEK_OF_MONTH, WEEK_OF_QUARTER
      ) values (
        @v_start_candle, @v_end_candle, @v_start_minute_key, @v_end_minute_key, @v_hour_key, @v_day_key, @v_week_key,
        @v_month_key,  @v_quarter_key  , @v_year_key, @v_day_key ,
        @v_crrnt_mnt, @v_crrnt_hr, @v_crrnt_d , @v_crrnt_wk, @v_crrnt_mnth, @v_crrnt_qrtr, @v_crrnt_yr,
        @v_day_of_week, @v_day_of_mnth, @v_day_of_yr,
        @v_week_of_mnth, @v_week_of_qrtr
      );
          
    end;  
    
    set @loaddate = dateadd(minute, @granularity , @loaddate)  ;    
    set @endloaddate = dateadd(minute, @granularity-1 , @loaddate)  ;
  end;
  if (@v_added <  @v_counter )
    print N'Added ' + convert(varchar, @v_added) + N'/' + convert(varchar, @v_counter) + N' (records cannot duplicate)';
  else  
    print N'Added ' + convert(varchar, @v_added) ;
end
GO

PRINT 'Procedure created'
GO
