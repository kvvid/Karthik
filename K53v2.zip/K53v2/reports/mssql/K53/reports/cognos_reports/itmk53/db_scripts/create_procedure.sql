--------------------------------------------------------------
--  IBM Tivoli Monitoring Agent Builder
-- 
--  (C) Copyright IBM Corporation 2011. All rights reserved. 
--
--  SQL Server 2005/2008 Script to populate ManagedSystem
--
--  This procedure populates the ManagedSystem table with the 
--  list of unique managed systems for a specified agent type. 
--  It obtains the list of managed systems by reading the 
--  following tables in the Tivoli Data Warehouse if they 
--  exist: 
--  * the agent's performance object status table
--  * discovery tables if the agent has subnodes
--  * availability if the agent collects process or service
--    data
--
--  Historical collection must be started on all these
--  attribute groups so that the managed system names can
--  be determined.
-- 
--  This procedure does NOT delete entries from the ManagedSystem 
--  table. It only adds managed systems that do not already exist 
--  in the table. Therefore values such as FullyQualifiedHostName 
--  can be updated later by the end user and the changes will not
--  be lost when the procedure is executed again.
--
--  This procedure should be executed periodically in order to 
--  process any new managed systems. Otherwise Cognos reports may
--  not include new managed systems that came online since the
--  populate_msn procedure was last run.
--
--  Prior to running this script, change all occurrences of
--  itmuser to your Tivoli Data Warehouse (TDW) user id.
--
--  To run the script from a Windows command line:
--  osql -S <server> -U <TDW id> -P <TDW password> -d <TDW database name> -n -I -i create_procedure.sql
--
--  To invoke the procedure:
--  osql -S <server> -U <TDW id> -P <TDW password> -d <TDW database name> -Q "EXEC [<TDW schema>].[kqz_populate_msn] @pv_productcode=N'<three letter product code>'"
--
--  Parameters:
--  pv_productcode:  The agent's three letter product code
-- 
--------------------------------------------------------------

-- Delete the procedure if it already exists
IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE 
    ROUTINE_NAME = N'kqz_populate_msn' AND ROUTINE_TYPE = N'PROCEDURE' 
    AND ROUTINE_SCHEMA = N'itmuser')
	DROP PROCEDURE itmuser.kqz_populate_msn;
GO


CREATE procedure itmuser.kqz_populate_msn
@pv_productcode varchar(3)
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @v_sql nvarchar(1024);
  DECLARE @v_table_name nvarchar(128);
  DECLARE @v_msn varchar(64);
  DECLARE @v_parent_msn varchar(64);
  DECLARE @v_product_code varchar(3);
  DECLARE @v_subnode_resource_name varchar(32);

  -- flags to indicate if we've read all of the rows from a 
  -- cursor
  DECLARE @v_at_end INTEGER;
  DECLARE @v_at_end_inner INTEGER;

  -- FullyQualifiedHostname is defined as NOT NULL in the 
  -- ManagedSystem table, so we have to provide a non blank
  -- value. 
  DECLARE @v_hostname varchar(384);
  DECLARE @v_table_count INTEGER;
  DECLARE @v_tdw_schema nvarchar(128);
 
  SET @v_hostname = 'N/A';
  
  -- change to your TDW schema value
  SET @v_tdw_schema = N'itmuser';

  -- make sure the product code is in upper case 
  SET @v_product_code = upper(@pv_productcode);

  -- We need to see if the agent's performance object status 
  --   table exists. It may not exist if:
  --   * an invalid product code was specified
  --   * historical collection was not enabled on the performance
  --     object status attribute group
  --   * historical collection was enabled on the performance 
  --     object status attribute group, but no data has been 
  --     exported to the Tivoli Data Warehouse
  --   * The agent only monitors processes or services
  SET @v_table_name = @v_product_code +
     '_PERFORMANCE_OBJECT_STATUS';

  -- There could be multiple copies of the table if the database
  -- has several schemas that contain Tivoli Data Warehouse 
  -- tables. Therefore, look for tables in the correct schema.
  SELECT @v_table_count = (SELECT COUNT(*) 
  FROM INFORMATION_SCHEMA.TABLES
  WHERE TABLE_NAME = @v_table_name
  AND TABLE_SCHEMA = @v_tdw_schema);

  -- The Performance Object Status table exists
  IF (@v_table_count <> 0) BEGIN   
    -- Get the list of MSNs from the Performance Object 
    -- Status table that do not already exist in the 
    -- ManagedSystem table
    SET @v_sql = 'DECLARE kqz_pos_cursor CURSOR FAST_FORWARD ' +
      'FOR SELECT DISTINCT "Node" FROM ' +
      @v_tdw_schema + '.' + @v_table_name + ' T1 ' +
      'WHERE NOT EXISTS (SELECT * FROM ' + 
      @v_tdw_schema + '.ManagedSystem T2 ' +
      'WHERE T1."Node" = T2.ManagedSystemName)';
     
    exec sp_executesql @v_sql;
    
    OPEN kqz_pos_cursor;
    
    BEGIN TRANSACTION;
    
    SET @v_at_end = 0;
    
    -- Process each of the managed systems
    WHILE (@v_at_end = 0) BEGIN
      FETCH NEXT FROM kqz_pos_cursor INTO @v_msn;

      IF @@FETCH_STATUS = 0 BEGIN 
        -- insert the new row into the ManagedSystem table 
        INSERT INTO itmuser.ManagedSystem
        (ManagedSystemName,FullyQualifiedHostname,DisplayName,
         AgentType,ParentMSN)
         VALUES 
        (@v_msn,@v_hostname,'N/A',@v_product_code,NULL);
      END
      ELSE BEGIN
        SET @v_at_end = 1;
      END;
    END;
    
    CLOSE kqz_pos_cursor;
    DEALLOCATE kqz_pos_cursor;
    
    COMMIT WORK;
  END
 
  -- there was no performance object status table, so look for
  -- the availability table 
  ELSE BEGIN

    -- We need to see if the agent's availabilty table  
    -- exists. Agents that monitor processes or services
    -- will have an availability table. The availability 
    -- table may not exist if:
    --   * an invalid product code was specified
    --   * historical collection was not enabled on the
    --     availability attribute group
    --   * historical collection was enabled on the availability 
    --     attribute group, but no data has been exported to 
    --     the Tivoli Data Warehouse
    --   * The agent does not monitor processes or services
    SET @v_table_name = @v_product_code +
       '_AVAILABILITY';
     
    -- There could be multiple copies of the table if 
    -- the database has several schemas that contain Tivoli 
    -- Data Warehouse tables. Therefore, look for tables in 
    -- the correct schema.
    SELECT @v_table_count = (SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_NAME = @v_table_name
    AND TABLE_SCHEMA = @v_tdw_schema);

    -- The Availability table exists
    IF (@v_table_count <> 0) BEGIN
      -- Get the list of MSNs from the availability table
      -- that do not already exist in the ManagedSystem table
      SET @v_sql = 'DECLARE kqz_avail_cursor ' +
        'CURSOR FAST_FORWARD ' +
        'FOR SELECT DISTINCT "Node" FROM ' +
        @v_tdw_schema + '.' + @v_table_name + ' T1 ' +
        ' WHERE NOT EXISTS (SELECT * FROM ' +
        @v_tdw_schema + '.ManagedSystem T2 ' +
        ' WHERE T1."Node" = T2.ManagedSystemName)';
      
      exec sp_executesql @v_sql;
    
      OPEN kqz_avail_cursor;
    
      BEGIN TRANSACTION;
    
      SET @v_at_end = 0;
    
      WHILE (@v_at_end = 0) BEGIN
        FETCH NEXT FROM kqz_avail_cursor INTO @v_msn;

        IF @@FETCH_STATUS = 0 BEGIN 
          -- insert the new row into the ManagedSystem table 
          INSERT INTO itmuser.ManagedSystem
          (ManagedSystemName,FullyQualifiedHostname,DisplayName,
           AgentType,ParentMSN)
           VALUES 
          (@v_msn,@v_hostname,'N/A',@v_product_code,NULL);
        END
        ELSE BEGIN
          SET @v_at_end = 1;
        END;
      END;
    
      CLOSE kqz_avail_cursor;
      DEALLOCATE kqz_avail_cursor;
    
      COMMIT WORK;
    END;
  END;

  --   Find all of the agent's discovery tables. There will be
  --   discovery tables if the agent has subnodes.  This is not 
  --   easy to do since the names of the tables do not follow a
  --   consistent naming convention. Therefore we have to look 
  --   for tables that have ALL of the following columns:
  --   Subnode_Affinity, Subnode_MSN, Subnode_Type, 
  --   Subnode_Resource_Name, Subnode_Version
  SET @v_sql = 'DECLARE kqz_table_cursor ' +
  'CURSOR FAST_FORWARD FOR ' +
  'SELECT TABLE_NAME FROM INFORMATION_SCHEMA.COLUMNS ' +
  'WHERE TABLE_NAME LIKE ''' +
  @v_product_code + '%'' ' +
  'AND COLUMN_NAME IN ( '+
  '''Subnode_Affinity'', ''Subnode_MSN'','+
  '''Subnode_Type'',''Subnode_Resource_Name'','+
  '''Subnode_Version'') ' +
  'GROUP BY TABLE_NAME ' +
  'HAVING COUNT(*) = 5';
  
  exec sp_executesql @v_sql;
    
  SET @v_at_end = 0;
    
  OPEN kqz_table_cursor;

  -- process each of the discovery tables 
  WHILE (@v_at_end = 0) BEGIN
    FETCH NEXT FROM kqz_table_cursor INTO @v_table_name;

    IF @@FETCH_STATUS = 0 BEGIN 
      -- now query the table for list of managed systems that 
      -- don't already exist in the ManagedSystem table 
      SET @v_sql = 'DECLARE kqz_msn_cursor ' +
        'CURSOR FAST_FORWARD ' + 
        'FOR SELECT DISTINCT "Node","Subnode_MSN",' +
        '"Subnode_Resource_Name" '+
        'FROM ' + @v_tdw_schema + '.' + @v_table_name + ' T1 ' + 
        'WHERE NOT EXISTS (SELECT * FROM ' + 
        @v_tdw_schema + '.ManagedSystem T2 ' +
        'WHERE T1."Subnode_MSN" = T2.ManagedSystemName)';
        
      exec sp_executesql @v_sql;
    
      SET @v_at_end_inner = 0;
      
      OPEN kqz_msn_cursor;

      BEGIN TRANSACTION;
      
      -- process each of the managed systems 
      WHILE (@v_at_end_inner = 0) BEGIN
        FETCH NEXT FROM kqz_msn_cursor INTO @v_parent_msn,@v_msn,
          @v_subnode_resource_name;

        IF @@FETCH_STATUS = 0 BEGIN 
          -- insert the new row into the ManagedSystem table
          INSERT INTO itmuser.ManagedSystem
          (ManagedSystemName,FullyQualifiedHostname,DisplayName,
           AgentType,ParentMSN)
          VALUES 
          (@v_msn,@v_hostname,@v_subnode_resource_name,
           @v_product_code,@v_parent_msn);
        END
        ELSE BEGIN
          SET @v_at_end_inner = 1;
        END;
      END; -- end of msn loop
      
      CLOSE kqz_msn_cursor;
      DEALLOCATE kqz_msn_cursor;

      COMMIT WORK;
    END
    ELSE BEGIN
      SET @v_at_end = 1;
    END;
  END; -- end of table loop
  
  CLOSE kqz_table_cursor;
  DEALLOCATE kqz_table_cursor;

END
