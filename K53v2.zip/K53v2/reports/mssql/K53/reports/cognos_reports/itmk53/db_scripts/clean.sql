----------------------------------------
--Build Date 11/03/28 17:21:38
----------------------------------------

SET NOCOUNT ON
USE IBM_TRAM
GO
drop procedure IBM_TRAM.CREATE_TIME_DIMENSION

drop TABLE IBM_TRAM.TIME_DIMENSION 
GO

drop TABLE IBM_TRAM.MONTH_LOOKUP
GO

drop TABLE IBM_TRAM.WEEKDAY_LOOKUP
GO

drop TABLE IBM_TRAM.TIMEZONE_DIMENSION
GO

drop TABLE IBM_TRAM.["ComputerSystem"]
GO

drop SCHEMA IBM_TRAM; 
GO
