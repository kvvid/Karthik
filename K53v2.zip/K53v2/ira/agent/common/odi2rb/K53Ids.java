// NLS_ENCODING=UTF-8
// NLS_MESSAGEFORMAT_NONE
// ----------------------------------------------------------------
// Monitoring Agent for Services
// Version 623
// Resource Bundle File
//
// COPYRIGHTS TIVOLI COE
//
// This file was created by the IBM Tivoli Monitoring Agent Builder
// Version 6.2.3.1
//	IBM Tivoli Monitoring Agent Generator 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder CIM Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder Custom Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder HTTP Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder ICMP Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring JDBC Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring JMX Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder Log Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder SNMP Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder WMI Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring TMS DLA Plugin 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder UI 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Remote Deploy 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder Common 6.2.3.1 201203140621
//	IBM Tivoli Omnibus 6.2.3 201203140621
// ----------------------------------------------------------------
package candle.k53.resources;
public interface K53Ids {
    public static final String K531000 = "K531000";
    public static final String K531001 = "K531001";
    public static final String K531002 = "K531002";
    public static final String K531003 = "K531003";
    public static final String K531004 = "K531004";
    public static final String K531005 = "K531005";
    public static final String K531006 = "K531006";
    public static final String K531007 = "K531007";
    public static final String K531008 = "K531008";
}
