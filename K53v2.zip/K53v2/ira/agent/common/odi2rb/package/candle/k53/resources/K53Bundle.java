// NLS_ENCODING=UTF-8
// NLS_MESSAGEFORMAT_NONE
// ----------------------------------------------------------------
// Monitoring Agent for Services
// Version 623
// Resource Bundle File
//
// COPYRIGHTS TIVOLI COE
//
// This file was created by the IBM Tivoli Monitoring Agent Builder
// Version 6.2.3.1
//	IBM Tivoli Monitoring Agent Generator 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder CIM Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder Custom Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder HTTP Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder ICMP Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring JDBC Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring JMX Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder Log Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder SNMP Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder WMI Data Provider 6.2.3.1 201203140621
//	IBM Tivoli Monitoring TMS DLA Plugin 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder UI 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Remote Deploy 6.2.3.1 201203140621
//	IBM Tivoli Monitoring Agent Builder Common 6.2.3.1 201203140621
//	IBM Tivoli Omnibus 6.2.3 201203140621
// ----------------------------------------------------------------
package candle.k53.resources;

import candle.kjr.resource.*;
import candle.kjr.util.*;
import java.util.*;

public class K53Bundle extends ListResourceBundle implements K53Ids, Versioned
    {
    public  static       String revisionNumber = "1.00";
    private static final String BUNDLE_ID       = "k53";
    private static final String BUNDLE_NAME     = "candle.k53.resources.K53Bundle";
    public  static       String PKGVERSION      = "@06230000";
    private static final IntegerVersion version = new IntegerVersion(100);

    private static final Object[][] contents =  {
        { K531000, "Services Montioring" },
        { K531001, "ServiceMon" },
        { K531002, "Monitoring of Windows Services" },
        { K531003, "Performance Object Status" },
        { K531004, "The Performance Object Status attribute group contains information that reflects the status of other attribute groups so you can see the status of all of the performance objects that make up this application all at once. Each of these other performance attribute groups is represented by a row in this table (or other type of view). The status for an attribute group reflects the result of the last attempt to collect data for that attribute group, which allows you to see whether the agent is performing correctly. Unlike other attribute groups, the Performance Object Status attribute group does not reflect the state of the monitored application. This attribute group is most often used to determine why data is " +
                   "not available for one of the performance attribute groups." },
        { K531005, "Thread Pool Status" },
        { K531006, "The Thread Pool Status attribute group contains information that reflects the status of the internal thread pool used to collect data asynchronously." },
        { K531007, "Take Action Status" },
        { K531008, "The Take Action Status attribute group contains information about the results of actions this agent has executed." },

    };

    public static final Bundle getBundle()
        {
        if (bundle == null)
            {
            bundle = new Bundle(BUNDLE_ID, BUNDLE_NAME, BundleManager.getCurrentLocale());
            bundle.addResourceLoader(new ImageLoader());
            bundle.addResourceLoader(new PanelLoader());
            BundleManager.addBundle(bundle);
            SingletonManager.add(bundle);
            }
        return bundle;
        }

    public Object[][] getContents()
        {
        return contents;
        }

    public Object getVersion()
        {
        return version.getVersion();
        }

    public int compareVersion(Object targetVersion)
        {
        return version.compareVersion(targetVersion);
        }

    private static Bundle bundle;
}
