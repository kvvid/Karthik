/*
 COPYRIGHT_COMMENT_TAG_BEGIN
 IBM Confidential
 OCO Source Materials
 5724-C04
 
 Copyright IBM Corp. 2005, 2011
 The source code for this program is not published or otherwise
 divested of its trade secrets, irrespective of what has
 been deposited with the U.S. Copyright Office.
 COPYRIGHT_COMMENT_TAG_END
 */
//***************************************************************************
//                                                                          *
// Unpublished Copyright (c) 1998, 2004 Candle Corporation.                 *
//                                                                          *
// All rights reserved.  International copyright secured.                   *
// USE PERMISSIBLE UNDER LICENSE ONLY.  This software may be                *
// protected by one or more United States and/or international              *
// patents or pending patent applications.                                  *
//                                                                          *
//***************************************************************************

/**
 * Resources
 * NLS_MESSAGEFORMAT_NONE (CHKPII flag indicating that the text is not 
 *                         processed by Java MessageFormat class)
 */

//***************************************************************************
//                >>>>  M A I N T E N A N C E    L O G  <<<<                *
//***************************************************************************
//  $Date: October 7, 2013 8:01:36 PM IST $
//  $Revision: 1.0 $
//
//***************************************************************************

// NLS_ENCODING=UTF-8
package candle.k53.resources;

import candle.kjr.resource.*;
import candle.kjr.util.*;
import java.util.*;
import java.lang.reflect.Method;

/**
 * <code>DocK53Bundle</code> contains K53 ODI definitions for NLS.
 *
 */

public class DocK53Bundle extends ResourceBundle implements Versioned
{
  private static final long serialVersionUID = 1L;

  private static final String BUNDLE_ID       = "dock53";
  private static final String BUNDLE_NAME     = "candle.k53.resources.DocK53Bundle";

  private static final IntegerVersion version = new IntegerVersion(100);

  // public Object[][] getContents() - needed for CHKPII tool
  
public Object[][] _oM1()
{
Object[][] contents = 
{
        {"%CG_Svcs.K53",                                  "Services Montioring"},
};
return contents;
}

public Object[][] _oM2()
{
Object[][] contents = 
{
        {"TABLE.K53CSCRIPT.OBJECT",                       "K53 SERVICEMON"},
        {"K53CSCRIPT.ORIGINNODE",                         "Node"},

        {"K53CSCRIPT.TIMESTAMP",                          "Timestamp"},

        {"K53CSCRIPT.DISPLAYNAM",                         "DisplayName"},

        {"K53CSCRIPT.STARTUPTYP",                         "StartupType"},

        {"K53CSCRIPT.STATUS",                             "Status"},

        {"K53CSCRIPT.MESSAGEGRO",                         "MessageGroup"},

        {"K53CSCRIPT.SEVERITY",                           "Severity"},

};
return contents;
}

public Object[][] _oM3()
{
Object[][] contents = 
{
        {"TABLE.K53POBJST.OBJECT",                        "K53 PERFORMANCE OBJECT STATUS"},
        {"K53POBJST.ORIGINNODE",                          "Node"},

        {"K53POBJST.TIMESTAMP",                           "Timestamp"},

        {"K53POBJST.ATTRGRP",                             "Query Name"},

        {"K53POBJST.OBJNAME",                             "Object Name"},

        {"K53POBJST.OBJTYPE",                             "Object Type"},
        {"K53POBJST.OBJTYPE.ENUM.0",                      "WMI"},
        {"K53POBJST.OBJTYPE.ENUM.1",                      "PERFMON"},
        {"K53POBJST.OBJTYPE.ENUM.10",                     "WMI REMOTE DATA"},
        {"K53POBJST.OBJTYPE.ENUM.11",                     "LOG FILE"},
        {"K53POBJST.OBJTYPE.ENUM.12",                     "JDBC"},
        {"K53POBJST.OBJTYPE.ENUM.13",                     "CONFIG DISCOVERY"},
        {"K53POBJST.OBJTYPE.ENUM.14",                     "NT EVENT LOG"},
        {"K53POBJST.OBJTYPE.ENUM.15",                     "FILTER"},
        {"K53POBJST.OBJTYPE.ENUM.16",                     "SNMP EVENT"},
        {"K53POBJST.OBJTYPE.ENUM.17",                     "PING"},
        {"K53POBJST.OBJTYPE.ENUM.18",                     "DIRECTOR DATA"},
        {"K53POBJST.OBJTYPE.ENUM.19",                     "DIRECTOR EVENT"},
        {"K53POBJST.OBJTYPE.ENUM.2",                      "WMI ASSOCIATION GROUP"},
        {"K53POBJST.OBJTYPE.ENUM.20",                     "SSH REMOTE SHELL COMMAND"},
        {"K53POBJST.OBJTYPE.ENUM.3",                      "JMX"},
        {"K53POBJST.OBJTYPE.ENUM.4",                      "SNMP"},
        {"K53POBJST.OBJTYPE.ENUM.5",                      "SHELL COMMAND"},
        {"K53POBJST.OBJTYPE.ENUM.6",                      "JOINED GROUPS"},
        {"K53POBJST.OBJTYPE.ENUM.7",                      "CIMOM"},
        {"K53POBJST.OBJTYPE.ENUM.8",                      "CUSTOM"},
        {"K53POBJST.OBJTYPE.ENUM.9",                      "ROLLUP DATA"},

        {"K53POBJST.OBJSTTS",                             "Object Status"},
        {"K53POBJST.OBJSTTS.ENUM.0",                      "ACTIVE"},
        {"K53POBJST.OBJSTTS.ENUM.1",                      "INACTIVE"},

        {"K53POBJST.ERRCODE",                             "Error Code"},
        {"K53POBJST.ERRCODE.ENUM.0",                      "NO ERROR"},
        {"K53POBJST.ERRCODE.ENUM.1",                      "GENERAL ERROR"},
        {"K53POBJST.ERRCODE.ENUM.10",                     "NO INSTANCES RETURNED"},
        {"K53POBJST.ERRCODE.ENUM.11",                     "ASSOCIATOR QUERY FAILED"},
        {"K53POBJST.ERRCODE.ENUM.12",                     "REFERENCE QUERY FAILED"},
        {"K53POBJST.ERRCODE.ENUM.13",                     "NO RESPONSE RECEIVED"},
        {"K53POBJST.ERRCODE.ENUM.14",                     "CANNOT FIND JOINED QUERY"},
        {"K53POBJST.ERRCODE.ENUM.15",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 1 RESULTS"},
        {"K53POBJST.ERRCODE.ENUM.16",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 2 RESULTS"},
        {"K53POBJST.ERRCODE.ENUM.17",                     "QUERY 1 NOT A SINGLETON"},
        {"K53POBJST.ERRCODE.ENUM.18",                     "QUERY 2 NOT A SINGLETON"},
        {"K53POBJST.ERRCODE.ENUM.19",                     "NO INSTANCES RETURNED IN QUERY 1"},
        {"K53POBJST.ERRCODE.ENUM.2",                      "OBJECT NOT FOUND"},
        {"K53POBJST.ERRCODE.ENUM.20",                     "NO INSTANCES RETURNED IN QUERY 2"},
        {"K53POBJST.ERRCODE.ENUM.21",                     "CANNOT FIND ROLLUP QUERY"},
        {"K53POBJST.ERRCODE.ENUM.22",                     "CANNOT FIND ROLLUP ATTRIBUTE"},
        {"K53POBJST.ERRCODE.ENUM.23",                     "FILE OFFLINE"},
        {"K53POBJST.ERRCODE.ENUM.24",                     "NO HOSTNAME"},
        {"K53POBJST.ERRCODE.ENUM.25",                     "MISSING LIBRARY"},
        {"K53POBJST.ERRCODE.ENUM.26",                     "ATTRIBUTE COUNT MISMATCH"},
        {"K53POBJST.ERRCODE.ENUM.27",                     "ATTRIBUTE NAME MISMATCH"},
        {"K53POBJST.ERRCODE.ENUM.28",                     "COMMON DATA PROVIDER NOT STARTED"},
        {"K53POBJST.ERRCODE.ENUM.29",                     "CALLBACK REGISTRATION ERROR"},
        {"K53POBJST.ERRCODE.ENUM.3",                      "COUNTER NOT FOUND"},
        {"K53POBJST.ERRCODE.ENUM.30",                     "MDL LOAD ERROR"},
        {"K53POBJST.ERRCODE.ENUM.31",                     "AUTHENTICATION FAILED"},
        {"K53POBJST.ERRCODE.ENUM.32",                     "CANNOT RESOLVE HOST NAME"},
        {"K53POBJST.ERRCODE.ENUM.33",                     "SUBNODE UNAVAILABLE"},
        {"K53POBJST.ERRCODE.ENUM.34",                     "SUBNODE NOT FOUND IN CONFIG"},
        {"K53POBJST.ERRCODE.ENUM.35",                     "ATTRIBUTE ERROR"},
        {"K53POBJST.ERRCODE.ENUM.36",                     "CLASSPATH ERROR"},
        {"K53POBJST.ERRCODE.ENUM.37",                     "CONNECTION FAILURE"},
        {"K53POBJST.ERRCODE.ENUM.38",                     "FILTER SYNTAX ERROR"},
        {"K53POBJST.ERRCODE.ENUM.39",                     "FILE NAME MISSING"},
        {"K53POBJST.ERRCODE.ENUM.4",                      "NAMESPACE ERROR"},
        {"K53POBJST.ERRCODE.ENUM.40",                     "SQL QUERY ERROR"},
        {"K53POBJST.ERRCODE.ENUM.41",                     "SQL FILTER QUERY ERROR"},
        {"K53POBJST.ERRCODE.ENUM.42",                     "SQL DB QUERY ERROR"},
        {"K53POBJST.ERRCODE.ENUM.43",                     "SQL DB FILTER QUERY ERROR"},
        {"K53POBJST.ERRCODE.ENUM.44",                     "PORT OPEN FAILED"},
        {"K53POBJST.ERRCODE.ENUM.45",                     "ACCESS DENIED"},
        {"K53POBJST.ERRCODE.ENUM.46",                     "TIMEOUT"},
        {"K53POBJST.ERRCODE.ENUM.47",                     "NOT IMPLEMENTED"},
        {"K53POBJST.ERRCODE.ENUM.48",                     "REQUESTED A BAD VALUE"},
        {"K53POBJST.ERRCODE.ENUM.49",                     "RESPONSE TOO BIG"},
        {"K53POBJST.ERRCODE.ENUM.5",                      "OBJECT CURRENTLY UNAVAILABLE"},
        {"K53POBJST.ERRCODE.ENUM.50",                     "GENERAL RESPONSE ERROR"},
        {"K53POBJST.ERRCODE.ENUM.51",                     "SCRIPT NONZERO RETURN"},
        {"K53POBJST.ERRCODE.ENUM.52",                     "SCRIPT NOT FOUND"},
        {"K53POBJST.ERRCODE.ENUM.53",                     "SCRIPT LAUNCH ERROR"},
        {"K53POBJST.ERRCODE.ENUM.54",                     "CONF FILE DOES NOT EXIST"},
        {"K53POBJST.ERRCODE.ENUM.55",                     "CONF FILE ACCESS DENIED"},
        {"K53POBJST.ERRCODE.ENUM.56",                     "INVALID CONF FILE"},
        {"K53POBJST.ERRCODE.ENUM.57",                     "EIF INITIALIZATION FAILED"},
        {"K53POBJST.ERRCODE.ENUM.58",                     "CANNOT OPEN FORMAT FILE"},
        {"K53POBJST.ERRCODE.ENUM.59",                     "FORMAT FILE SYNTAX ERROR"},
        {"K53POBJST.ERRCODE.ENUM.6",                      "COM LIBRARY INIT FAILURE"},
        {"K53POBJST.ERRCODE.ENUM.60",                     "REMOTE HOST UNAVAILABLE"},
        {"K53POBJST.ERRCODE.ENUM.61",                     "EVENT LOG DOES NOT EXIST"},
        {"K53POBJST.ERRCODE.ENUM.62",                     "PING FILE DOES NOT EXIST"},
        {"K53POBJST.ERRCODE.ENUM.63",                     "NO PING DEVICE FILES"},
        {"K53POBJST.ERRCODE.ENUM.64",                     "PING DEVICE LIST FILE MISSING"},
        {"K53POBJST.ERRCODE.ENUM.65",                     "SNMP MISSING PASSWORD"},
        {"K53POBJST.ERRCODE.ENUM.66",                     "DISABLED"},
        {"K53POBJST.ERRCODE.ENUM.67",                     "URLS FILE NOT FOUND"},
        {"K53POBJST.ERRCODE.ENUM.68",                     "XML PARSE ERROR"},
        {"K53POBJST.ERRCODE.ENUM.69",                     "NOT INITIALIZED"},
        {"K53POBJST.ERRCODE.ENUM.7",                      "SECURITY INIT FAILURE"},
        {"K53POBJST.ERRCODE.ENUM.9",                      "PROXY SECURITY FAILURE"},

        {"K53POBJST.COLSTRT",                             "Last Collection Start"},
        {"K53POBJST.COLSTRT.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"K53POBJST.COLSTRT.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"K53POBJST.COLFINI",                             "Last Collection Finished"},
        {"K53POBJST.COLFINI.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"K53POBJST.COLFINI.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"K53POBJST.COLDURA",                             "Last Collection Duration"},

        {"K53POBJST.COLAVGD",                             "Average Collection Duration"},
        {"K53POBJST.COLAVGD.ENUM.-100",                   "NO DATA"},

        {"K53POBJST.REFRINT",                             "Refresh Interval"},

        {"K53POBJST.NUMCOLL",                             "Number of Collections"},

        {"K53POBJST.CACHEHT",                             "Cache Hits"},

        {"K53POBJST.CACHEMS",                             "Cache Misses"},

        {"K53POBJST.CACHPCT",                             "Cache Hit Percent"},

        {"K53POBJST.INTSKIP",                             "Intervals Skipped"},

};
return contents;
}

public Object[][] _oM4()
{
Object[][] contents = 
{
        {"TABLE.K53THPLST.OBJECT",                        "K53 THREAD POOL STATUS"},
        {"K53THPLST.ORIGINNODE",                          "Node"},

        {"K53THPLST.TIMESTAMP",                           "Timestamp"},

        {"K53THPLST.THPSIZE",                             "Thread Pool Size"},
        {"K53THPLST.THPSIZE.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.THPSIZE.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPMAXSZ",                             "Thread Pool Max Size"},
        {"K53THPLST.TPMAXSZ.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPMAXSZ.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPACTTH",                             "Thread Pool Active Threads"},
        {"K53THPLST.TPACTTH.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPACTTH.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPAVGAT",                             "Thread Pool Avg Active Threads"},
        {"K53THPLST.TPAVGAT.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPAVGAT.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPMINAT",                             "Thread Pool Min Active Threads"},
        {"K53THPLST.TPMINAT.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPMINAT.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPMAXAT",                             "Thread Pool Max Active Threads"},
        {"K53THPLST.TPMAXAT.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPMAXAT.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPQLGTH",                             "Thread Pool Queue Length"},
        {"K53THPLST.TPQLGTH.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPQLGTH.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPAVGQL",                             "Thread Pool Avg Queue Length"},
        {"K53THPLST.TPAVGQL.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPAVGQL.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPMINQL",                             "Thread Pool Min Queue Length"},
        {"K53THPLST.TPMINQL.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPMINQL.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPMAXQL",                             "Thread Pool Max Queue Length"},
        {"K53THPLST.TPMAXQL.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPMAXQL.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPAVJBW",                             "Thread Pool Avg Job Wait"},
        {"K53THPLST.TPAVJBW.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPAVJBW.ENUM.-100",                   "NO DATA"},

        {"K53THPLST.TPTJOBS",                             "Thread Pool Total Jobs"},
        {"K53THPLST.TPTJOBS.ENUM.-1",                     "NO DATA"},
        {"K53THPLST.TPTJOBS.ENUM.-100",                   "NO DATA"},

};
return contents;
}

public Object[][] _oM5()
{
Object[][] contents = 
{
        {"TABLE.K53TACTST.OBJECT",                        "K53 TAKE ACTION STATUS"},
        {"K53TACTST.ORIGINNODE",                          "Node"},

        {"K53TACTST.TIMESTAMP",                           "Timestamp"},

        {"K53TACTST.TSKNAME",                             "Action Name"},

        {"K53TACTST.TSKSTAT",                             "Action Status"},
        {"K53TACTST.TSKSTAT.ENUM.0",                      "OK"},
        {"K53TACTST.TSKSTAT.ENUM.1",                      "NOT APPLICABLE"},
        {"K53TACTST.TSKSTAT.ENUM.10",                     "UNKNOWN"},
        {"K53TACTST.TSKSTAT.ENUM.11",                     "DEPENDENT STILL RUNNING"},
        {"K53TACTST.TSKSTAT.ENUM.12",                     "INSUFFICIENT USER AUTHORITY"},
        {"K53TACTST.TSKSTAT.ENUM.2",                      "GENERAL ERROR"},
        {"K53TACTST.TSKSTAT.ENUM.3",                      "WARNING"},
        {"K53TACTST.TSKSTAT.ENUM.4",                      "NOT RUNNING"},
        {"K53TACTST.TSKSTAT.ENUM.5",                      "DEPENDENT NOT RUNNING"},
        {"K53TACTST.TSKSTAT.ENUM.6",                      "ALREADY RUNNING"},
        {"K53TACTST.TSKSTAT.ENUM.7",                      "PREREQ NOT RUNNING"},
        {"K53TACTST.TSKSTAT.ENUM.8",                      "TIMED OUT"},
        {"K53TACTST.TSKSTAT.ENUM.9",                      "DOESNT EXIST"},

        {"K53TACTST.TSKAPRC",                             "Action App Return Code"},

        {"K53TACTST.TSKMSGE",                             "Action Message"},

        {"K53TACTST.TSKINST",                             "Action Instance"},

        {"K53TACTST.TSKOUTP",                             "Action Results"},

        {"K53TACTST.TSKCMND",                             "Action Command"},

        {"K53TACTST.TSKORGN",                             "Action Node"},

        {"K53TACTST.TSKSBND",                             "Action Subnode"},

        {"K53TACTST.TSKID",                               "Action ID"},

        {"K53TACTST.TSKTYPE",                             "Action Type"},
        {"K53TACTST.TSKTYPE.ENUM.0",                      "UNKNOWN"},
        {"K53TACTST.TSKTYPE.ENUM.1",                      "AUTOMATION"},

        {"K53TACTST.TSKOWNR",                             "Action Owner"},

};
return contents;
}

 
  /**
   * Provide access to singleton Bundle wrapper for this resource bundle.
   *
   * @return reference to Bundle wrapper for this resource bundle
   */
//  Begin do not translate block
  public static final Bundle getBundle()
  {
    // if singleton bundle not yet created ...
    if (bundle == null)
    {
      // ... create it now
      bundle = new Bundle(BUNDLE_ID, BUNDLE_NAME, BundleManager.getCurrentLocale());
      BundleManager.addBundle(bundle);

      // make long-lived reference to singleton instance
      SingletonManager.add(bundle);
    }

    // return result
    return bundle;
  }

  /**
   * Implements Versioned interface
   */
  public Object getVersion()
  {
    return version.getVersion();
  }

  /**
   * Implements Versioned interface
   */
  public int compareVersion(Object targetVersion)
  {
    return version.compareVersion(targetVersion);
  }

  /**
   * Implementation of ResourceBundle.getKeys.
   */
  public Enumeration getKeys()
  {
    if (map.isEmpty())
      loadMap();

    return new Enumeration()
    {
      private Iterator mi = map.keySet().iterator();

      public boolean hasMoreElements()
      {
        return mi.hasNext();
      }

      public Object nextElement()
      {
        return mi.next();
      }
    };
  }

  /**
   * Gets an object for the given key from this resource bundle.
   * Returns null if this resource bundle does not contain an
   * object for the given key.
   *
   * @param key the key for the desired object
   * @exception NullPointerException if <code>key</code> is <code>null</code>
   * @return the object for the given key, or null
   */
  public Object handleGetObject(String key)
  {
    if (key == null)
      throw new NullPointerException();

    if (map.isEmpty())
      loadMap();

    return map.get(key); 
  }

  // load the resource map
  private void loadMap() 
  {
    Method[] methods = getClass().getDeclaredMethods();

    try
    {
      for (int i=0; i < methods.length; i++)
      {
        Method method = methods[i];

        if (method.getName().startsWith("_oM")) // one of the resource methods
        {
          Object[][] contents = (Object[][])method.invoke(this, (Object[]) null);

          for (int j = 0; j < contents.length; ++j)
          {
            map.put((String)contents[j][0], contents[j][1]);
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  private static Bundle bundle;
  private static HashMap map = new HashMap(43);
//End do not translate block
}
